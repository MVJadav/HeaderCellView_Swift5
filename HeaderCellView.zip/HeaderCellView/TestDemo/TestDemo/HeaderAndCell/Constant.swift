//
//  Constant.swift
//  TestDemo
//
//  Created by Mehul Jadav on 30/08/19.
//  Copyright © 2019 mac. All rights reserved.
//

import Foundation
import UIKit

let appDelegate = UIApplication.shared.delegate as! AppDelegate
