//
//  AppUtility.swift
//  TestDemo
//
//  Created by Mehul Jadav on 30/08/19.
//  Copyright © 2019 mac. All rights reserved.
//

import Foundation
import UIKit

class AppUtility: NSObject {
    
    /// Shared instance of AppUtility.
    public static let `default` = AppUtility()
    @objc var navigationController: UINavigationController?

}
